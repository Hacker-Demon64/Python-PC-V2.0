print('Calculator')
num56 = input('Enter first number: ')
op   = input('Enter Operator: ')
num2 = input('Enter Second Number: ')

if op == '+':
    print(int(num56)+int(num2))
elif op == '-':
    print(int(num56)-int(num2))
elif op == '*':
    print(int(num56)*int(num2))
elif op == '/':
    print(int(num56)/int(num2))
else:
    print('Invalid Operator')