try:
    import random
    import os
    # create a options
    options = ['rock', 'paper', 'scissors']
    # create a function to play the game
    computer = random.choice(options)
    You = input('You: ')
    print('Computer: ' + computer)
    # create a statment which compares each one to another of the options
    if You == 'rock' and computer == 'rock':
        print('It is a tie')
    elif You == 'rock' and computer == 'paper':
        print('You Won!')
    elif You == 'rock' and computer == 'scissors':
        print('You Won!')
    elif You == 'paper' and computer == 'rock':
        print('You Won!')
    elif You == 'paper' and computer == 'paper':
        print('It is a tie')
    elif You == 'paper' and computer == 'scissors':
        print('You Lost!')
    elif You == 'scissors' and computer == 'rock':
        print('You Lost!')
    elif You == 'scissors' and computer == 'paper':
        print('You Won')
    elif You == 'scissors' and computer == 'scissors':
        print('It is a tie')
    def Restart():
        print('Restarting Game...')
        
    rstrt = input('Do You Want To Restart?: ')
    if rstrt == 'yes':
        Restart()
    elif rstrt == 'no':
        print('Goodbye')
        quit()
# Create A Except Block Which Doesn't Work
except:
    print('Catastrophic Error Has Occurred')