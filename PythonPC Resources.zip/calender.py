import calendar

yeras = input('Enter Year: ')
monthas = input('Enter Month: ')
year = yeras
month = monthas
print(calendar.month(int(year), int(month))) 