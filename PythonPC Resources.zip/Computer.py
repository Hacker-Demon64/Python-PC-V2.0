import os
import time
import sys

acc = ['admin']
pas = ['admin']

print('Booting...')
time.sleep(4)

def creative():
    apps  = input('Which App Do You Want To Use?: ')
    if apps == 'guess the number':
        os.system('python gtn.py')
        creative()
    elif apps == 'calendar':
                os.system('python Calender.py')
                creative()
    elif apps == 'calculator':
                os.system('python calculator.py')
                creative()
    elif apps == 'rock paper scissors':
                os.system('python rps.py') 
                creative() 
    else:
        print('Apps: Guess the Number, Calendar, Calculator, Rock-paper-scissors')

def logon():
    login = input('Do You Want To Login? (y/n): ')
    if login == 'y':
        access = input('Enter Your Username: ')
        if access in acc:
            password = input('Enter Your Password: ')
            if password in pas:
                print('Access Granted')
                print('Apps: Guess the Number, Calendar, Calculator, Rock-paper-scissors')
                creative()
    elif login == 'n':
        accrt = input('What Will Be The Username?: ')
        pasrt = input('What Will Be The Password?: ')
        acc.append(accrt)
        pas.append(pasrt)
        print('Registry Updating...')
        time.sleep(7)
        print('Registry Updated Successfully!', file=sys.stderr)
        print('Apps: Guess the Number, Calendar, Calculator, Rock-paper-scissors')
        creative()
        
logon()

