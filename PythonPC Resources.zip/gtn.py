# Introduction To The Number Guessing Game
print('Welcome To The Number Guessing Game!')
print('Good Luck Trying To Win!')
# Importing The Necessary Modules
import random
guess = random.randint(1, 100)
askme = None
print('I am thinking of a number between 1 and 100')
# Creating The Loop And Defining The Values
while guess != askme:
    askme = int(input('What is your guess?: '))
    if askme > guess:
        print('Dont Go Too High Lower Down !')
    elif askme < guess:
        print('Dont Go Too Low Lower Down !')
    elif askme == guess:
        print('You Got It Right')
    else:
        print('Out Of Range or Str Entered')