try:
    from colorama import Fore
    import os
    hi = input('C:/Users/Admin: ')  
    if hi == "color":
        asd = input('Which Color Do You Want To Use?: ')
        if asd == "red":
            hi = input(Fore.RED + 'C:/Users/Admin/> ')
            os.system('python Command_Prompt.py')
        elif asd == "green":
            hi = input(Fore.GREEN + 'C:/Users/Admin/> ')
            os.system('python Command_Prompt.py')
        elif asd == "blue":
            hi = input(Fore.BLUE + 'C:/Users/Admin/> ')
            os.system('python Command_Prompt.py')
    elif hi == 'prompt':
        asdv = input('What Would You like The Prompt Name To Be?> ')
        hi = input(asdv)
        os.system('python Command_Prompt.py')
    elif hi == 'cd':
        dvc = input('Where Would You Like The Path Directory To Be?> ')
        hi = input(dvc + ">")
        os.system('python Command_Prompt.py')
    elif hi == 'echo':
        asker = input('What Would You Like To Say?> ')
        print(asker)
        os.system('python Command_Prompt.py')
    elif hi == 'mkdir':
        directory = input('What Would Name Will The Folder Name> ')
        os.mkdir(directory)
        print('Creating Directory...')
        os.system('python Command_Prompt.py')
    elif hi == 'rmdir':
        directory = input('Enter Folder Location> ')
        os.rmdir(directory)
        print('Removing Directory...')
        os.system('python Command_Prompt.py')
    # Make A Help Function
    elif hi == 'help':
        print('\nThis is a list of commands:')
        print('color: To change the color of the terminal')
        print('prompt: To change the color of the terminal')
        print('echo: To echo a string')
        print('mkdir: To make a directory')
        print('rmdir: To remove a directory')
        print('help: To show this message')
        print('exit: To exit the program')
        os.system('python Command_Prompt.py')
    # Create A Exit Function
    elif hi == 'exit':
        print('Exiting The Program...')
        quit()
    else:
        print('Invalid Input')
        os.system('python Command_Prompt.py') 
except SyntaxError:
    print('Insufficient Permissions Or Code Issues')
    os.system('python Command_Prompt.py')